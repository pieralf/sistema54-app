import { useState, useEffect, useRef } from 'react';
import { useForm, useFieldArray, Controller } from 'react-hook-form';
import { ChevronLeft, Plus, Trash2, Printer, Monitor, Wrench, Receipt, Save, AlertCircle, Search, UserPlus, X, Package, PenTool, Home } from 'lucide-react';
import { IOSCard, IOSInput, IOSToggle } from '../components/ui/ios-elements';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import SignatureCanvas from 'react-signature-canvas';
import { API_URL } from '../config/api';

// --- TIPI ---
type AssetDetail = {
  categoria_it: "Hardware" | "Software" | "Network" | "Generico";
  marca_modello: string;
  serial_number: string;
  part_number?: string;
  descrizione_lavoro: string;
};

type Ricambio = {
  descrizione: string;
  quantita: number;
  prezzo_unitario: number;
  prodotto_id?: number;
};

type FormValues = {
  macro_categoria: "Printing & Office" | "Informatica & IT" | "Manutenzione Gen." | "Sistemi Fiscali";
  cliente_id: number;
  cliente_ragione_sociale: string;
  cliente_indirizzo: string;
  sede_id?: number;
  dettagli: AssetDetail[];
  is_contratto: boolean;
  is_garanzia: boolean;
  is_chiamata: boolean;
  is_sopralluogo: boolean;
  flag_diritto_chiamata: boolean;
  ora_inizio?: string; // Formato HH:MM
  ora_fine?: string; // Formato HH:MM
  costi_extra: number;
  descrizione_extra: string;
  difetto_segnalato?: string; // Campo separato per il difetto segnalato
  ricambi: Ricambio[];
  firma_tecnico?: string;
  firma_cliente?: string;
  nome_cliente?: string;
  cognome_cliente?: string;
};

// --- MODALE NUOVO CLIENTE ---
const NewClientModal = ({ isOpen, onClose, onClientCreated }: any) => {
    const { register, handleSubmit, watch, formState: { errors }, getValues } = useForm();
    const isPa = watch("is_pa");

    const onSave = async (data: any) => {
        try {
            const res = await axios.post(`${API_URL}/clienti/`, {
                ...data,
                citta: data.citta || "-",
                cap: data.cap || "00000"
            });
            onClientCreated(res.data);
            onClose();
        } catch (err: any) {
            const msg = err.response?.data?.detail || "Errore sconosciuto.";
            alert("Attenzione: " + msg);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm transition-all">
            <div className="bg-white rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl animate-in zoom-in-95 flex flex-col max-h-[90vh]">
                <div className="bg-blue-600 p-4 flex justify-between items-center text-white shrink-0">
                    <h3 className="font-bold flex items-center gap-2"><UserPlus className="w-5 h-5" /> Nuovo Cliente</h3>
                    <button onClick={onClose} className="hover:bg-blue-700 p-1 rounded-full"><X className="w-6 h-6" /></button>
                </div>
                <div className="p-4 space-y-3 overflow-y-auto">
                    <div>
                        <IOSInput label="Ragione Sociale *" {...register("ragione_sociale", { required: "Campo obbligatorio" })} />
                        {errors.ragione_sociale && <p className="text-red-500 text-xs mt-1 ml-1">{String(errors.ragione_sociale.message)}</p>}
                    </div>
                    <div>
                        <IOSInput label="Indirizzo Completo *" {...register("indirizzo", { required: "Campo obbligatorio" })} />
                        {errors.indirizzo && <p className="text-red-500 text-xs mt-1 ml-1">{String(errors.indirizzo.message)}</p>}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                         <div><IOSInput label="P.IVA" {...register("p_iva")} /></div>
                         <div><IOSInput label="Codice Fiscale" {...register("codice_fiscale")} /></div>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-xl border border-gray-200">
                        <label className="flex items-center gap-2 font-semibold text-sm mb-2 text-gray-700 cursor-pointer">
                            <input type="checkbox" {...register("is_pa")} className="w-4 h-4 rounded text-blue-600" /> È Pubblica Amministrazione
                        </label>
                        {isPa && (
                            <div className="grid grid-cols-2 gap-3 animate-in fade-in">
                                <IOSInput label="Codice SDI" {...register("codice_sdi")} />
                                <IOSInput label="PEC" {...register("email_amministrazione")} />
                            </div>
                        )}
                    </div>
                    <button onClick={handleSubmit(onSave)} className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-bold mt-4 shadow-lg">SALVA ANAGRAFICA</button>
                </div>
            </div>
        </div>
    );
};

// --- MODALE CERCA PRODOTTO ---
const ProductSearchModal = ({ isOpen, onClose, onProductSelect }: any) => {
    const [searchTerm, setSearchTerm] = useState("");
    const [results, setResults] = useState<any[]>([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (!isOpen) { setResults([]); setSearchTerm(""); return; }
        const delay = setTimeout(async () => {
             if(!searchTerm) return;
             setLoading(true);
             try {
                const res = await axios.get(`${API_URL}/magazzino/?q=${searchTerm}`);
                setResults(res.data);
            } catch (e) { console.error(e); }
            finally { setLoading(false); }
        }, 300);
        return () => clearTimeout(delay);
    }, [searchTerm, isOpen]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
            <div className="bg-white rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[80vh]">
                <div className="bg-green-600 p-4 flex justify-between items-center text-white shrink-0">
                    <h3 className="font-bold flex items-center gap-2"><Package className="w-5 h-5" /> Cerca in Magazzino</h3>
                    <button onClick={onClose}><X className="w-6 h-6" /></button>
                </div>
                <div className="p-4 border-b bg-white">
                    <div className="relative">
                        <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                        <input autoFocus type="text" className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 pl-10 pr-4 outline-none focus:ring-2 focus:ring-green-500" placeholder="Cerca codice o descrizione..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                    </div>
                </div>
                <div className="flex-1 overflow-y-auto p-2 space-y-2 bg-gray-50/50">
                    {loading && <div className="text-center py-4 text-gray-400">Ricerca in corso...</div>}
                    {!loading && results.map(p => (
                        <div key={p.id} onClick={() => onProductSelect(p)} className="p-3 bg-white border border-gray-100 rounded-xl hover:bg-green-50 hover:border-green-200 cursor-pointer flex justify-between items-center shadow-sm">
                            <div>
                                <div className="font-bold text-gray-800">{p.descrizione}</div>
                                <div className="text-xs text-gray-500 font-mono">{p.codice_articolo}</div>
                            </div>
                            <div className="text-right">
                                <div className="font-bold text-green-700">€ {p.prezzo_vendita.toFixed(2)}</div>
                                <div className={`text-xs font-bold ${p.giacenza > 0 ? 'text-gray-500' : 'text-red-500'}`}>Giacenza: {p.giacenza}</div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

// --- MODALE FIRMA PROFESSIONALE (MIGLIORATA) ---
const SignatureModal = ({ isOpen, onClose, onConfirm, formData }: any) => {
    const sigPadRef = useRef<any>(null);
    const [step, setStep] = useState(1); 
    const [tempTecnico, setTempTecnico] = useState<string>("");
    const [isDrawing, setIsDrawing] = useState(false);
    const [nomeCliente, setNomeCliente] = useState(formData?.nome_cliente || '');
    const [cognomeCliente, setCognomeCliente] = useState(formData?.cognome_cliente || '');

    // Reset quando si apre
    useEffect(() => {
        if (isOpen) {
            setStep(1);
            setTempTecnico("");
            setIsDrawing(false);
            setNomeCliente(formData?.nome_cliente || '');
            setCognomeCliente(formData?.cognome_cliente || '');
        }
    }, [isOpen, formData]);

    // Reset canvas quando cambia step
    useEffect(() => {
        if (sigPadRef.current && isOpen) {
            sigPadRef.current.clear();
        }
    }, [step, isOpen]);

    if (!isOpen) return null;

    const handleNext = () => {
        if (sigPadRef.current && sigPadRef.current.isEmpty()) {
            alert("⚠️ Errore: Manca la firma del tecnico.");
            return;
        }
        const data = sigPadRef.current.getTrimmedCanvas().toDataURL('image/png');
        setTempTecnico(data);
        setStep(2);
    };

    const handleFinish = () => {
        if (sigPadRef.current && sigPadRef.current.isEmpty()) {
            alert("⚠️ Errore: Manca la firma del cliente.");
            return;
        }
        if (!nomeCliente.trim() || !cognomeCliente.trim()) {
            alert("⚠️ Errore: Inserisci nome e cognome del firmatario.");
            return;
        }
        const firmaCliente = sigPadRef.current.getTrimmedCanvas().toDataURL('image/png');
        onConfirm(tempTecnico, firmaCliente, nomeCliente.trim(), cognomeCliente.trim());
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-md">
            <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl animate-in zoom-in-95">
                <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-5 text-white flex justify-between items-center">
                    <h3 className="font-bold text-lg flex items-center gap-2">
                        <PenTool className="w-6 h-6" /> 
                        Firma Digitale {step === 1 ? "Tecnico (1/2)" : "Cliente (2/2)"}
                    </h3>
                    <button onClick={onClose} className="hover:bg-white/20 p-2 rounded-full transition-colors">
                        <X className="w-6 h-6" />
                    </button>
                </div>
                
                <div className="p-6 md:p-8">
                    <div key={step} className="space-y-5 animate-in fade-in">
                        <div className="text-center">
                            <p className="text-base font-semibold text-gray-800 mb-1">
                                {step === 1 ? "Firma del Tecnico Esecutore" : "Firma Cliente per Accettazione"}
                            </p>
                            <p className="text-xs text-gray-500">
                                {step === 1 
                                    ? "Firma nell'area sottostante utilizzando il dito o lo stilo" 
                                    : "Il cliente deve firmare per accettare l'intervento"}
                            </p>
                        </div>
                        
                        {/* Canvas Firma - Ottimizzato per Touch */}
                        <div className="border-3 border-dashed border-blue-300 rounded-2xl bg-gradient-to-br from-gray-50 to-white p-2 shadow-inner">
                            <div className="relative bg-white rounded-xl overflow-hidden" style={{ height: '300px', touchAction: 'none' }}>
                                <SignatureCanvas 
                                    ref={sigPadRef}
                                    penColor="#1e293b"
                                    backgroundColor="transparent"
                                    velocityFilterWeight={0.7}
                                    minWidth={2}
                                    maxWidth={3}
                                    throttle={16}
                                    onBegin={() => setIsDrawing(true)}
                                    onEnd={() => setIsDrawing(false)}
                                    canvasProps={{
                                        className: 'w-full h-full touch-none',
                                        style: { touchAction: 'none' }
                                    }} 
                                />
                                {!isDrawing && sigPadRef.current?.isEmpty() && (
                                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                                        <p className="text-gray-300 text-sm font-medium">Firma qui</p>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Controlli */}
                        <div className="flex gap-3">
                            <button 
                                onClick={() => sigPadRef.current?.clear()} 
                                className="flex-1 text-sm text-red-600 hover:text-red-700 hover:bg-red-50 py-2.5 rounded-xl font-semibold transition-all border border-red-200"
                            >
                                🗑️ Pulisci
                            </button>
                            {step === 1 ? (
                                <button 
                                    onClick={handleNext} 
                                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-xl font-bold transition-all shadow-md"
                                >
                                    Avanti →
                                </button>
                            ) : (
                                <>
                                    <button 
                                        onClick={() => setStep(1)} 
                                        className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 py-2.5 rounded-xl font-semibold transition-all"
                                    >
                                        ← Indietro
                                    </button>
                                    <button 
                                        onClick={handleFinish} 
                                        className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2.5 rounded-xl font-bold transition-all shadow-md flex items-center justify-center gap-2"
                                    >
                                        <Save className="w-4 h-4" /> Conferma
                                    </button>
                                </>
                            )}
                        </div>

                        {/* Campi Nome/Cognome Firmatario - Solo nel passo 2 */}
                        {step === 2 && (
                            <>
                                <div className="space-y-3 mt-4">
                                    <div>
                                        <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                                            Nome Firmatario *
                                        </label>
                                        <input
                                            type="text"
                                            value={nomeCliente}
                                            onChange={(e) => setNomeCliente(e.target.value)}
                                            className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                                            placeholder="Nome"
                                            required
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                                            Cognome Firmatario *
                                        </label>
                                        <input
                                            type="text"
                                            value={cognomeCliente}
                                            onChange={(e) => setCognomeCliente(e.target.value)}
                                            className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                                            placeholder="Cognome"
                                            required
                                        />
                                    </div>
                                </div>
                                
                                {/* Disclaimer Legale */}
                                <div className="bg-amber-50 border-l-4 border-amber-400 p-4 rounded-lg mt-4">
                                    <p className="text-xs text-amber-800 leading-relaxed text-justify">
                                        <strong>⚠️ Attenzione:</strong> Firmando, il cliente dichiara che i lavori sono stati eseguiti a regola d'arte e accetta le condizioni generali di contratto ex art. 2222 C.C. La firma digitale ha valore legale equivalente alla firma autografa.
                                    </p>
                                </div>
                            </>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

// --- PAGINA PRINCIPALE ---
export default function NewInterventionPage() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [settings, setSettings] = useState<any>(null);
  const navigate = useNavigate();

  // Stati Modali
  const [isClientModalOpen, setIsClientModalOpen] = useState(false);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [isSignatureModalOpen, setIsSignatureModalOpen] = useState(false);
  
  // Ricerca Cliente
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [contractLocked, setContractLocked] = useState(false);
  const [clienteMultisede, setClienteMultisede] = useState<any>(null);
  const [sediCliente, setSediCliente] = useState<any[]>([]);
  
  // Dati temporanei
  const [formDataTemp, setFormDataTemp] = useState<any>(null);
  
  const { register, control, handleSubmit, watch, setValue } = useForm<FormValues>({
    defaultValues: {
      macro_categoria: "Informatica & IT",
      dettagli: [{ categoria_it: "Hardware", marca_modello: "", serial_number: "", part_number: "", descrizione_lavoro: "" }],
      flag_diritto_chiamata: true,
      ora_inizio: "",
      ora_fine: new Date().toTimeString().slice(0, 5), // Default = ora corrente
      costi_extra: 0,
      descrizione_extra: "",
      difetto_segnalato: "",
      ricambi: []
    }
  });

  const { fields: assetFields, append: appendAsset, remove: removeAsset } = useFieldArray({ control, name: "dettagli" });
  const { fields: ricambiFields, append: appendRicambio, remove: removeRicambio } = useFieldArray({ control, name: "ricambi" });

  const isContratto = watch("is_contratto");
  const macroCategoria = watch("macro_categoria");
  const clienteSelezionato = watch("cliente_ragione_sociale");
  const ricambiValues = watch("ricambi");
  
  const totaleRicambi = ricambiValues?.reduce((acc, curr) => acc + ((Number(curr.quantita) || 0) * (Number(curr.prezzo_unitario) || 0)), 0) || 0;

  useEffect(() => {
    axios.get(`${API_URL}/impostazioni/`).then(res => setSettings(res.data)).catch(console.error);
  }, []);

  useEffect(() => {
    // Se contratto è attivo, disabilita chiamata
    if (isContratto) {
      setValue("flag_diritto_chiamata", false);
    }
  }, [isContratto, setValue]);

  useEffect(() => {
      const delay = setTimeout(async () => {
        if (searchTerm.length > 2) {
            try {
                const res = await axios.get(`${API_URL}/clienti/?q=${searchTerm}`);
                setSearchResults(res.data);
                setShowResults(true);
            } catch (e) { console.error(e); }
        } else {
            setSearchResults([]); setShowResults(false);
        }
      }, 300);
      return () => clearTimeout(delay);
  }, [searchTerm]);

  const selezionaCliente = async (c: any) => {
      setValue("cliente_id", c.id);
      setValue("cliente_ragione_sociale", c.ragione_sociale);
      setValue("cliente_indirizzo", c.indirizzo);
      setValue("is_contratto", c.has_contratto_assistenza || false);
      setContractLocked(c.has_contratto_assistenza || false);
      setValue("sede_id", undefined); // Reset sede selezionata
      setSearchTerm(""); setShowResults(false);
      
      // Se il cliente ha multisede, carica le sedi
      if (c.has_multisede) {
        try {
          const res = await axios.get(`${API_URL}/clienti/${c.id}/sedi`);
          setSediCliente(res.data);
          setClienteMultisede(c);
        } catch (err) {
          console.error('Errore caricamento sedi:', err);
          setSediCliente([]);
          setClienteMultisede(null);
        }
      } else {
        setSediCliente([]);
        setClienteMultisede(null);
      }
      
      // Gestione contratto/chiamata in base al cliente
      if (c.has_contratto_assistenza) {
        // Cliente CON contratto: contratto attivo, chiamata disabilitata
        setValue("is_contratto", true);
        setValue("flag_diritto_chiamata", false);
      } else {
        // Cliente SENZA contratto: chiamata attiva di default
        setValue("is_contratto", false);
        setValue("flag_diritto_chiamata", true);
      }
  };

  const handleAddProductFromStore = (product: any) => {
      appendRicambio({ descrizione: product.descrizione, quantita: 1, prezzo_unitario: product.prezzo_vendita, prodotto_id: product.id });
      setIsProductModalOpen(false);
  };

  const getCurrentPrice = () => {
    if (!settings?.tariffe_categorie) return 0;
    return settings.tariffe_categorie[macroCategoria]?.chiamata || 30.00;
  };

  const onSubmit = (data: FormValues) => {
    if (!data.cliente_id) { alert("Seleziona un cliente!"); return; }
    setFormDataTemp(data);
    setIsSignatureModalOpen(true);
  };

 // --- LOGICA CRITICA: SALVATAGGIO CON DEBUG AVANZATO ---
  const handleSignatureConfirm = async (firmaTec: string, firmaCli: string, nomeCliente: string, cognomeCliente: string) => {
    console.log("Inizio processo di salvataggio..."); 
    setIsSignatureModalOpen(false);
    setIsSubmitting(true);
    
    try {
        // 1. Pulizia e Preparazione Dati
        // Pydantic (Backend) è severo: se un campo stringa è obbligatorio, non può essere vuoto o null.
        const dettagliPuliti = formDataTemp.dettagli.map((d: any) => ({
            ...d,
            // Se marca_modello è vuota, mettiamo un trattino per evitare errore 422
            marca_modello: d.marca_modello?.trim() || "-", 
            // Idem per la descrizione
            descrizione_lavoro: d.descrizione_lavoro?.trim() || "-",
            // Serial number è opzionale nel backend, quindi stringa vuota va bene (diventerà null)
            serial_number: d.serial_number || "",
            // Part number è opzionale
            part_number: d.part_number || null
        }));

        const finalData = {
            ...formDataTemp,
            firma_tecnico: firmaTec,
            firma_cliente: firmaCli,
            nome_cliente: nomeCliente,
            cognome_cliente: cognomeCliente,
            dettagli: dettagliPuliti,
            // Forziamo i numeri
            costi_extra: Number(formDataTemp.costi_extra) || 0,
            cliente_id: Number(formDataTemp.cliente_id),
            sede_id: formDataTemp.sede_id ? Number(formDataTemp.sede_id) : null,
            ricambi: formDataTemp.ricambi ? formDataTemp.ricambi.map((r: any) => ({
                ...r,
                quantita: Number(r.quantita),
                prezzo_unitario: Number(r.prezzo_unitario)
            })) : []
        };


        // 2. Chiamata API
        const response = await axios.post(`${API_URL}/interventi/`, finalData);
      
        // 3. Successo
        const nuovoId = response.data.id;
        const numeroRit = response.data.numero_relazione;

        // Scarica e apre il PDF con autenticazione
        let pdfOpened = false;
        try {
          const pdfResponse = await axios.get(`${API_URL}/interventi/${nuovoId}/pdf`, {
            responseType: 'blob',
          });
          
          // Verifica che il contenuto sia valido
          if (pdfResponse.data && pdfResponse.data.size > 0) {
            // Crea un URL blob dal PDF
            const blob = new Blob([pdfResponse.data], { type: 'application/pdf' });
            const url = window.URL.createObjectURL(blob);
            
            // Apri in una nuova finestra
            const pdfWindow = window.open(url, '_blank');
            if (pdfWindow) {
              pdfOpened = true;
              // Pulisci l'URL dopo un delay più lungo per permettere il caricamento
              setTimeout(() => window.URL.revokeObjectURL(url), 5000);
            } else {
              // Se il popup è bloccato, scarica il file
              const link = document.createElement('a');
              link.href = url;
              link.download = `${numeroRit}.pdf`;
              link.click();
              pdfOpened = true;
              setTimeout(() => window.URL.revokeObjectURL(url), 1000);
            }
          } else {
            console.error('PDF vuoto o non valido');
          }
        } catch (pdfErr: any) {
          console.error('Errore apertura PDF:', pdfErr);
          const errorMsg = pdfErr.response?.data?.detail || pdfErr.message || 'Errore sconosciuto';
          alert(`⚠️ R.I.T. ${numeroRit} CREATO!\n\nErrore nell'apertura del PDF: ${errorMsg}\n\nPuoi scaricarlo dall'archivio interventi.`);
        }
      
        if (pdfOpened) {
          alert(`✅ R.I.T. ${numeroRit} CREATO!\nIl PDF si sta aprendo in un'altra scheda.`);
        }
        navigate('/');
      
    } catch (error: any) {
      console.error("ERRORE SALVATAGGIO:", error);
      
      // 4. Gestione Errore Leggibile
      let errorMsg = "Errore sconosciuto";
      
      if (error.response?.data?.detail) {
          const detail = error.response.data.detail;
          if (Array.isArray(detail)) {
              // Se è un array di errori Pydantic, li formattiamo
              errorMsg = detail.map((e: any) => `Campo: ${e.loc.join('.')} -> ${e.msg}`).join('\n');
          } else {
              errorMsg = String(detail);
          }
      } else {
          errorMsg = error.message;
      }

      alert(`❌ ERRORE DATI (422):\n${errorMsg}\n\nControlla di aver compilato tutti i campi obbligatori (es. Marca/Modello).`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const MacroCatCard = ({ value, icon: Icon, label }: any) => (
    <div onClick={() => setValue("macro_categoria", value)} className={`cursor-pointer p-3 rounded-xl border flex flex-col items-center justify-center gap-2 transition-all ${macroCategoria === value ? 'bg-blue-50 border-blue-500 text-blue-700 shadow-md transform scale-[1.02]' : 'bg-white border-gray-200 text-gray-400 hover:border-blue-300'}`}>
        <Icon className="w-6 h-6" />
        <span className="text-[10px] font-bold uppercase text-center">{label}</span>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50/50 pb-20 relative font-sans">
      <NewClientModal isOpen={isClientModalOpen} onClose={() => setIsClientModalOpen(false)} onClientCreated={selezionaCliente} />
      <ProductSearchModal isOpen={isProductModalOpen} onClose={() => setIsProductModalOpen(false)} onProductSelect={handleAddProductFromStore} />
      
      {/* MODALE FIRMA */}
      <SignatureModal 
        isOpen={isSignatureModalOpen} 
        onClose={() => setIsSignatureModalOpen(false)} 
        onConfirm={handleSignatureConfirm}
        formData={formDataTemp}
      />

      <header className="sticky top-0 z-10 bg-white/90 backdrop-blur-md border-b border-gray-200 px-4 py-3 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => navigate('/')} 
            className="p-2 -ml-2 text-gray-600 rounded-full hover:bg-gray-100"
            title="Home"
          >
            <Home className="w-6 h-6" />
          </button>
          <button 
            onClick={() => navigate(-1)} 
            className="p-2 text-gray-600 rounded-full hover:bg-gray-100"
            title="Torna indietro"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-lg font-bold text-gray-900 tracking-tight">Nuovo Intervento</h1>
        </div>
        <button onClick={handleSubmit(onSubmit)} disabled={isSubmitting} className={`text-sm font-semibold flex items-center gap-2 px-4 py-2 rounded-full transition-all ${isSubmitting ? 'bg-gray-100 text-gray-400' : 'bg-blue-600 text-white hover:bg-blue-700 shadow-lg shadow-blue-200'}`}>
          {isSubmitting ? 'Attendere...' : <><Save className="w-4 h-4" /> Firma</>}
        </button>
      </header>

      <main className="max-w-3xl mx-auto p-4 sm:p-6 space-y-4 sm:space-y-6">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
            <MacroCatCard value="Printing & Office" icon={Printer} label="Print" />
            <MacroCatCard value="Informatica & IT" icon={Monitor} label="IT" />
            <MacroCatCard value="Sistemi Fiscali" icon={Receipt} label="Fiscali" />
            <MacroCatCard value="Manutenzione Gen." icon={Wrench} label="Altro" />
        </div>

        <IOSCard className="overflow-visible">
            <div className="flex justify-between items-center mb-3">
                 <h2 className="font-bold text-gray-900 text-base">Cliente</h2>
                 <button onClick={() => setIsClientModalOpen(true)} className="text-xs font-bold bg-blue-50 text-blue-600 px-3 py-1.5 rounded-full flex items-center gap-1 border border-blue-100"><UserPlus className="w-3 h-3" /> NUOVO</button>
            </div>
            <div className="relative z-20">
                {!clienteSelezionato ? (
                    <>
                        <div className="relative group">
                            <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                            <input type="text" className="w-full bg-white border border-gray-200 rounded-xl py-3 pl-10 pr-4 outline-none focus:ring-2 focus:ring-blue-500 shadow-sm" placeholder="Cerca Ragione Sociale..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                        </div>
                        {showResults && searchResults.length > 0 && (
                            <div className="absolute top-full left-0 right-0 bg-white border border-gray-200 rounded-xl shadow-xl mt-2 max-h-64 overflow-y-auto z-30">
                                {searchResults.map(c => (
                                    <div key={c.id} onClick={() => selezionaCliente(c)} className="p-3 hover:bg-blue-50 cursor-pointer border-b last:border-0">
                                        <div className="font-bold text-gray-800">{c.ragione_sociale}</div>
                                        <div className="text-xs text-gray-500">{c.indirizzo}</div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </>
                ) : (
                    <div className="bg-blue-50/50 border border-blue-200 rounded-xl p-4 relative">
                        <button onClick={() => { 
                          setValue("cliente_id", 0); 
                          setValue("cliente_ragione_sociale", ""); 
                          setValue("sede_id", undefined);
                          setSediCliente([]);
                          setClienteMultisede(null);
                        }} className="absolute top-3 right-3 text-blue-300 hover:text-red-500"><X className="w-4 h-4" /></button>
                        <div className="font-bold text-blue-900 text-lg pr-8">{clienteSelezionato}</div>
                        
                        {clienteMultisede && sediCliente.length > 0 ? (
                          <div className="mt-3">
                            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5 ml-1">
                              Seleziona Sede
                            </label>
                            <select
                              {...register("sede_id")}
                              onChange={(e) => {
                                const sedeId = e.target.value ? parseInt(e.target.value) : undefined;
                                setValue("sede_id", sedeId);
                                if (sedeId) {
                                  const sede = sediCliente.find(s => s.id === sedeId);
                                  if (sede) {
                                    setValue("cliente_indirizzo", sede.indirizzo_completo);
                                  }
                                } else {
                                  setValue("cliente_indirizzo", clienteMultisede.indirizzo);
                                }
                              }}
                              className="w-full bg-white border border-gray-200 rounded-xl py-2.5 px-3 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                            >
                              <option value="">Sede Centrale/Legale</option>
                              {sediCliente.map((sede) => (
                                <option key={sede.id} value={sede.id}>
                                  {sede.nome_sede}
                                </option>
                              ))}
                            </select>
                            <div className="text-sm text-blue-600/80 mt-2">
                              {watch("sede_id") ? (
                                sediCliente.find(s => s.id === parseInt(watch("sede_id")?.toString() || "0"))?.indirizzo_completo
                              ) : (
                                watch("cliente_indirizzo")
                              )}
                            </div>
                          </div>
                        ) : (
                          <div className="text-sm text-blue-600/80 mt-1">{watch("cliente_indirizzo")}</div>
                        )}
                    </div>
                )}
            </div>
        </IOSCard>

        <div>
             <div className="flex justify-between items-end mb-3 px-1">
                <h2 className="text-xs font-bold text-gray-500 uppercase tracking-widest">Dettaglio Lavori</h2>
                <button type="button" onClick={() => appendAsset({ categoria_it: "Hardware", marca_modello: "", serial_number: "", part_number: "", descrizione_lavoro: "" })} className="text-xs font-bold text-blue-600 bg-white px-3 py-1.5 rounded-full flex items-center border border-gray-200 shadow-sm"><Plus className="w-3 h-3 mr-1" /> AGGIUNGI</button>
            </div>
            <div className="space-y-4">
                {assetFields.map((field, index) => (
                    <div key={field.id} className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm relative group">
                        <button type="button" onClick={() => removeAsset(index)} className="absolute top-4 right-4 text-gray-300 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                        <div className="mb-4 flex items-center gap-2"><span className="text-[10px] font-bold bg-gray-100 text-gray-500 px-2 py-1 rounded border border-gray-200 uppercase">Asset #{index + 1}</span></div>
                        {macroCategoria === "Informatica & IT" && (
                            <select {...register(`dettagli.${index}.categoria_it`)} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none mb-3">
                                <option value="Hardware">Hardware</option><option value="Software">Software</option><option value="Network">Network</option>
                            </select>
                        )}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3">
                            <IOSInput label="Prodotto / Modello" {...register(`dettagli.${index}.marca_modello`)} />
                            <IOSInput label="Serial Number" {...register(`dettagli.${index}.serial_number`)} />
                            <IOSInput label="Part Number" {...register(`dettagli.${index}.part_number`)} />
                        </div>
                        <textarea {...register(`dettagli.${index}.descrizione_lavoro`)} rows={3} className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm outline-none" placeholder="Descrizione lavoro..." />
                    </div>
                ))}
            </div>
        </div>

        <IOSCard className="mt-6">
          <h2 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 px-1">Difetto Segnalato</h2>
          <textarea {...register("difetto_segnalato")} rows={3} className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm outline-none" placeholder="Descrivi il difetto segnalato dal cliente..." />
        </IOSCard>

        <IOSCard className="mt-6 border-l-4 border-l-blue-600 shadow-md">
          <h2 className="text-lg font-bold text-gray-900 mb-5 flex items-center"><Receipt className="w-5 h-5 mr-2 text-blue-600" /> Condizioni & Costi</h2>
          <div className="grid grid-cols-2 gap-4 mb-6">
             <div className={contractLocked ? "opacity-60 pointer-events-none grayscale" : ""}>
               <Controller 
                 name="is_contratto" 
                 control={control} 
                 render={({ field }) => (
                   <IOSToggle 
                     label="Contratto" 
                     checked={field.value} 
                     onChange={(checked) => {
                       field.onChange(checked);
                       if (checked) {
                         setValue("flag_diritto_chiamata", false);
                       }
                     }} 
                   />
                 )} 
               />
             </div>
             <Controller name="is_garanzia" control={control} render={({ field }) => <IOSToggle label="Garanzia" checked={field.value} onChange={field.onChange} />} />
             <Controller name="is_chiamata" control={control} render={({ field }) => <IOSToggle label="Chiamata" checked={field.value} onChange={field.onChange} />} />
             <Controller name="is_sopralluogo" control={control} render={({ field }) => <IOSToggle label="Sopralluogo" checked={field.value} onChange={field.onChange} />} />
          </div>
          
          {/* Orari */}
          <div className="bg-blue-50 p-4 rounded-xl mb-4 border border-blue-200/60">
            <h3 className="font-semibold text-gray-900 text-sm mb-3">Orari Intervento</h3>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5 ml-1">
                  Ora Inizio *
                </label>
                <input 
                  type="time" 
                  {...register("ora_inizio", { required: "Ora inizio obbligatoria" })} 
                  className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5 ml-1">
                  Ora Fine *
                </label>
                <input 
                  type="time" 
                  {...register("ora_fine", { required: "Ora fine obbligatoria" })} 
                  className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-xl space-y-4 border border-gray-200/60">
            <div className="flex items-center justify-between">
                <div>
                  <div className="font-semibold text-gray-900 text-sm">Diritto di Chiamata</div>
                  <div className="text-xs text-gray-500">
                    {isContratto ? "Incluso nel contratto" : `Tariffa: € ${getCurrentPrice().toFixed(2)}`}
                  </div>
                </div>
                <Controller 
                  name="flag_diritto_chiamata" 
                  control={control} 
                  render={({ field }) => (
                    <div className={isContratto ? "opacity-50 pointer-events-none" : ""}>
                      <IOSToggle label="" checked={field.value} onChange={field.onChange} />
                    </div>
                  )} 
                />
            </div>
            <div className="border-t border-gray-200 pt-4 grid grid-cols-3 gap-2">
                <div className="col-span-2">
                  <input 
                    {...register("descrizione_extra")} 
                    placeholder="Costi Extra (Descrizione)" 
                    className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none" 
                  />
                </div>
                <div className="col-span-1">
                  <input 
                    type="number" 
                    step="0.01" 
                    {...register("costi_extra", {valueAsNumber: true})} 
                    placeholder="€ 0.00" 
                    className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-right text-sm outline-none" 
                  />
                </div>
            </div>
          </div>
        </IOSCard>

        <IOSCard>
            <div className="flex justify-between items-center mb-4">
                <h2 className="font-bold text-gray-900">Ricambi</h2>
                <div className="flex gap-2">
                    <button type="button" onClick={() => setIsProductModalOpen(true)} className="text-[10px] font-bold bg-green-50 text-green-700 px-3 py-2 rounded-full flex items-center border border-green-200"><Search className="w-3 h-3 mr-1" /> MAGAZZINO</button>
                    <button type="button" onClick={() => appendRicambio({ descrizione: "", quantita: 1, prezzo_unitario: 0 })} className="text-[10px] font-bold bg-blue-50 text-blue-700 px-3 py-2 rounded-full flex items-center border border-blue-200"><Plus className="w-3 h-3 mr-1" /> MANUALE</button>
                </div>
            </div>
            <div className="space-y-3">
                {ricambiFields.map((field, index) => (
                    <div key={field.id} className="flex gap-2 items-start">
                        <input {...register(`ricambi.${index}.descrizione`)} className="bg-white border p-2 rounded-lg w-full text-sm" placeholder="Descrizione" />
                        <input type="number" {...register(`ricambi.${index}.quantita`, {valueAsNumber: true})} className="bg-white border p-2 rounded-lg w-16 text-center text-sm" placeholder="Qt" />
                        <input type="number" step="0.01" {...register(`ricambi.${index}.prezzo_unitario`, {valueAsNumber: true})} className="bg-white border p-2 rounded-lg w-24 text-right text-sm" placeholder="€" />
                        <button type="button" onClick={() => removeRicambio(index)} className="text-red-400 p-2"><Trash2 className="w-4 h-4" /></button>
                    </div>
                ))}
            </div>
            {ricambiFields.length > 0 && <div className="mt-5 pt-4 border-t text-right font-bold font-mono">Totale Materiale: € {totaleRicambi.toFixed(2)}</div>}
        </IOSCard>
      </main>
    </div>
  );
}