"""
Servizio per l'invio di email
"""
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional
import os

def send_email(
    to_email: str,
    subject: str,
    body_html: str,
    body_text: Optional[str] = None
) -> bool:
    """
    Invia un'email usando SMTP
    
    Args:
        to_email: Email destinatario
        subject: Oggetto email
        body_html: Corpo email in HTML
        body_text: Corpo email in testo (opzionale)
    
    Returns:
        True se inviata con successo, False altrimenti
    """
    # Configurazione SMTP (può essere configurata via variabili d'ambiente)
    smtp_host = os.getenv("SMTP_HOST", "smtp.gmail.com")
    smtp_port = int(os.getenv("SMTP_PORT", "587"))
    smtp_user = os.getenv("SMTP_USER", "")
    smtp_password = os.getenv("SMTP_PASSWORD", "")
    smtp_from = os.getenv("SMTP_FROM", smtp_user)
    
    # Se non configurato, usa mock
    if not smtp_user or not smtp_password:
        print(f"--- [EMAIL MOCK] ---")
        print(f"TO: {to_email}")
        print(f"SUBJECT: {subject}")
        print(f"BODY: {body_text or body_html[:200]}...")
        print("--------------------")
        return True
    
    try:
        # Crea messaggio
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = smtp_from
        msg['To'] = to_email
        
        # Aggiungi corpo
        if body_text:
            part1 = MIMEText(body_text, 'plain')
            msg.attach(part1)
        
        part2 = MIMEText(body_html, 'html')
        msg.attach(part2)
        
        # Invia email
        with smtplib.SMTP(smtp_host, smtp_port) as server:
            server.starttls()
            server.login(smtp_user, smtp_password)
            server.send_message(msg)
        
        print(f"Email inviata con successo a {to_email}")
        return True
        
    except Exception as e:
        print(f"Errore invio email a {to_email}: {str(e)}")
        return False

def generate_scadenza_noleggio_email(
    cliente_nome: str,
    asset_info: dict,
    azienda_nome: str,
    azienda_telefono: str,
    azienda_email: str
) -> tuple[str, str]:
    """
    Genera il contenuto email per notifica scadenza noleggio
    
    Returns:
        (subject, body_html)
    """
    tipo_macchina = asset_info.get('tipo_asset', 'Macchina')
    nome_macchina = ""
    if tipo_macchina == 'Printing':
        nome_macchina = f"{asset_info.get('marca', '')} {asset_info.get('modello', '')}".strip()
    else:
        nome_macchina = asset_info.get('descrizione', 'Prodotto IT')
    
    data_scadenza = asset_info.get('data_scadenza_noleggio', '')
    if data_scadenza:
        try:
            from datetime import datetime
            if isinstance(data_scadenza, str):
                data_scadenza = datetime.fromisoformat(data_scadenza.replace('Z', '+00:00'))
            data_formattata = data_scadenza.strftime('%d/%m/%Y')
        except:
            data_formattata = str(data_scadenza)
    else:
        data_formattata = "Non specificata"
    
    subject = f"Avviso Scadenza Noleggio - {nome_macchina}"
    
    body_html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
            .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
            .header {{ background-color: #4F46E5; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }}
            .content {{ background-color: #f9fafb; padding: 30px; border: 1px solid #e5e7eb; }}
            .footer {{ background-color: #f3f4f6; padding: 15px; text-align: center; font-size: 12px; color: #6b7280; border-radius: 0 0 5px 5px; }}
            .info-box {{ background-color: #fff; border-left: 4px solid #4F46E5; padding: 15px; margin: 20px 0; }}
            .button {{ display: inline-block; background-color: #4F46E5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin-top: 20px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Avviso Scadenza Noleggio</h1>
            </div>
            <div class="content">
                <p>Gentile {cliente_nome},</p>
                
                <p>Le comunichiamo che il contratto di noleggio della seguente macchina è in scadenza:</p>
                
                <div class="info-box">
                    <strong>Macchina:</strong> {nome_macchina}<br>
                    <strong>Data Scadenza:</strong> {data_formattata}
                </div>
                
                <p>La scadenza è prevista tra <strong>30 giorni</strong>. Per garantire la continuità del servizio, 
                la invitiamo a contattarci per richiedere un nuovo preventivo.</p>
                
                <p>I nostri contatti:</p>
                <ul>
                    <li><strong>Telefono:</strong> {azienda_telefono or 'Non disponibile'}</li>
                    <li><strong>Email:</strong> {azienda_email or 'Non disponibile'}</li>
                </ul>
                
                <p>Restiamo a disposizione per qualsiasi chiarimento.</p>
                
                <p>Cordiali saluti,<br>
                <strong>{azienda_nome}</strong></p>
            </div>
            <div class="footer">
                <p>Questa è una comunicazione automatica. Si prega di non rispondere a questa email.</p>
            </div>
        </div>
    </body>
    </html>
    """
    
    body_text = f"""
Avviso Scadenza Noleggio

Gentile {cliente_nome},

Le comunichiamo che il contratto di noleggio della seguente macchina è in scadenza:

Macchina: {nome_macchina}
Data Scadenza: {data_formattata}

La scadenza è prevista tra 30 giorni. Per garantire la continuità del servizio, 
la invitiamo a contattarci per richiedere un nuovo preventivo.

I nostri contatti:
- Telefono: {azienda_telefono or 'Non disponibile'}
- Email: {azienda_email or 'Non disponibile'}

Restiamo a disposizione per qualsiasi chiarimento.

Cordiali saluti,
{azienda_nome}

---
Questa è una comunicazione automatica. Si prega di non rispondere a questa email.
    """
    
    return subject, body_html

