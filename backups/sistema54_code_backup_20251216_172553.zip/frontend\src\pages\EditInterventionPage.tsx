import { useState, useEffect, useRef } from 'react';
import { useForm, useFieldArray, Controller } from 'react-hook-form';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, Plus, Trash2, Printer, Monitor, Wrench, Receipt, Save, AlertCircle, Search, UserPlus, X, Package, PenTool, Home } from 'lucide-react';
import { IOSCard, IOSInput, IOSToggle } from '../components/ui/ios-elements';
import axios from 'axios';
import SignatureCanvas from 'react-signature-canvas';
import { API_URL } from '../config/api';
import { useAuthStore } from '../store/authStore';

// --- TIPI ---
type AssetDetail = {
  categoria_it: "Hardware" | "Software" | "Network" | "Generico";
  marca_modello: string;
  serial_number: string;
  part_number?: string;
  descrizione_lavoro: string;
};

type Ricambio = {
  descrizione: string;
  quantita: number;
  prezzo_unitario: number;
  prodotto_id?: number;
};

type FormValues = {
  macro_categoria: "Printing & Office" | "Informatica & IT" | "Manutenzione Gen." | "Sistemi Fiscali";
  cliente_id: number;
  cliente_ragione_sociale: string;
  cliente_indirizzo: string;
  sede_id?: number;
  dettagli: AssetDetail[];
  is_contratto: boolean;
  is_garanzia: boolean;
  is_chiamata: boolean;
  is_sopralluogo: boolean;
  flag_diritto_chiamata: boolean;
  ora_inizio?: string;
  ora_fine?: string;
  costi_extra: number;
  descrizione_extra: string;
  difetto_segnalato?: string;
  ricambi: Ricambio[];
  firma_tecnico?: string;
  firma_cliente?: string;
  nome_cliente?: string;
  cognome_cliente?: string;
};

export default function EditInterventionPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { token } = useAuthStore();
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [clienteMultisede, setClienteMultisede] = useState<any>(null);
  const [sediCliente, setSediCliente] = useState<any[]>([]);
  const [isSignatureModalOpen, setIsSignatureModalOpen] = useState(false);
  const [formDataTemp, setFormDataTemp] = useState<any>(null);
  const [contractLocked, setContractLocked] = useState(false);
  const [numeroRit, setNumeroRit] = useState<string>("");
  
  const sigCanvasTecnico = useRef<SignatureCanvas>(null);
  const sigCanvasCliente = useRef<SignatureCanvas>(null);

  const { register, control, handleSubmit, watch, setValue, reset } = useForm<FormValues>();

  const assetFields = useFieldArray({
    control,
    name: "dettagli"
  });

  const ricambiFields = useFieldArray({
    control,
    name: "ricambi"
  });

  const macroCategoria = watch("macro_categoria");

  // Carica dati intervento esistente
  useEffect(() => {
    const loadIntervento = async () => {
      if (!token) {
        console.error("Token non disponibile");
        navigate("/login");
        return;
      }
      
      // Assicurati che il token sia nell'header
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      
      try {
        const response = await axios.get(`${API_URL}/interventi/${id}`, {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        const intervento = response.data;
        
        // Salva il numero RIT per visualizzarlo nell'header
        if (intervento.numero_relazione) {
          setNumeroRit(intervento.numero_relazione);
        }
        
        // Carica sedi se cliente multisede
        if (intervento.cliente_id) {
          const clienteRes = await axios.get(`${API_URL}/clienti/${intervento.cliente_id}`, {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });
          const cliente = clienteRes.data;
          if (cliente.has_multisede && cliente.sedi) {
            setClienteMultisede(cliente);
            setSediCliente(cliente.sedi);
          }
          if (cliente.has_contratto_assistenza) {
            setContractLocked(true);
          }
        }

        // Prepara dati per il form
        const formData = {
          macro_categoria: intervento.macro_categoria,
          cliente_id: intervento.cliente_id,
          cliente_ragione_sociale: intervento.cliente_ragione_sociale,
          cliente_indirizzo: intervento.cliente_indirizzo,
          sede_id: intervento.sede_id || null,
          dettagli: intervento.dettagli && intervento.dettagli.length > 0 
            ? intervento.dettagli.map((d: any) => ({
                categoria_it: d.categoria_it || "Hardware",
                marca_modello: d.marca_modello || "",
                serial_number: d.serial_number || "",
                part_number: d.part_number || "",
                descrizione_lavoro: d.descrizione_lavoro || ""
              }))
            : [{ categoria_it: "Hardware", marca_modello: "", serial_number: "", part_number: "", descrizione_lavoro: "" }],
          is_contratto: intervento.is_contratto || false,
          is_garanzia: intervento.is_garanzia || false,
          is_chiamata: intervento.is_chiamata || false,
          is_sopralluogo: intervento.is_sopralluogo || false,
          flag_diritto_chiamata: intervento.flag_diritto_chiamata !== false,
          ora_inizio: intervento.ora_inizio || "",
          ora_fine: intervento.ora_fine || new Date().toTimeString().slice(0, 5),
          costi_extra: intervento.costi_extra || 0,
          descrizione_extra: intervento.descrizione_extra || "",
          difetto_segnalato: intervento.difetto_segnalato || "",
          ricambi: intervento.ricambi_utilizzati && intervento.ricambi_utilizzati.length > 0
            ? intervento.ricambi_utilizzati.map((r: any) => ({
                descrizione: r.descrizione || "",
                quantita: r.quantita || 1,
                prezzo_unitario: r.prezzo_unitario || 0,
                prodotto_id: r.prodotto_id || undefined
              }))
            : [],
          nome_cliente: intervento.nome_cliente || "",
          cognome_cliente: intervento.cognome_cliente || ""
        };

        reset(formData);
        setLoading(false);
      } catch (error: any) {
        console.error("Errore caricamento intervento:", error);
        if (error.response?.status === 401) {
          alert("Sessione scaduta. Effettua nuovamente il login.");
          navigate("/login");
        } else {
          alert("Errore nel caricamento del RIT: " + (error.response?.data?.detail || error.message));
          navigate("/admin?tab=interventi");
        }
      }
    };

    if (id && token) {
      loadIntervento();
    }
  }, [id, navigate, reset, token]);

  const handleSignatureConfirm = async () => {
    if (!sigCanvasTecnico.current || !sigCanvasCliente.current) return;
    
    if (!token) {
      alert("Sessione scaduta. Effettua nuovamente il login.");
      navigate("/login");
      return;
    }

    const firmaTec = sigCanvasTecnico.current.toDataURL();
    const firmaCli = sigCanvasCliente.current.toDataURL();
    const nomeCliente = (document.getElementById('nome_cliente') as HTMLInputElement)?.value || "";
    const cognomeCliente = (document.getElementById('cognome_cliente') as HTMLInputElement)?.value || "";

    if (!firmaTec || !firmaCli) {
      alert("Entrambe le firme sono obbligatorie");
      return;
    }

    setIsSubmitting(true);
    
    // Assicurati che il token sia nell'header
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    
    try {
      const formData = watch();
      const formDataTemp = { ...formData };

      const dettagliPuliti = formDataTemp.dettagli.map((d: any) => ({
        ...d,
        marca_modello: d.marca_modello?.trim() || "-",
        descrizione_lavoro: d.descrizione_lavoro?.trim() || "-",
        serial_number: d.serial_number || "",
        part_number: d.part_number || null
      }));

      const finalData = {
        ...formDataTemp,
        firma_tecnico: firmaTec,
        firma_cliente: firmaCli,
        nome_cliente: nomeCliente,
        cognome_cliente: cognomeCliente,
        dettagli: dettagliPuliti,
        costi_extra: Number(formDataTemp.costi_extra) || 0,
        cliente_id: Number(formDataTemp.cliente_id),
        sede_id: formDataTemp.sede_id ? Number(formDataTemp.sede_id) : null,
        ricambi: formDataTemp.ricambi ? formDataTemp.ricambi.map((r: any) => ({
          ...r,
          quantita: Number(r.quantita),
          prezzo_unitario: Number(r.prezzo_unitario)
        })) : []
      };

      const updateResponse = await axios.put(`${API_URL}/interventi/${id}`, finalData, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      // Aggiorna il numero RIT dalla risposta
      const updatedNumeroRit = updateResponse.data?.numero_relazione || numeroRit;
      if (updatedNumeroRit) {
        setNumeroRit(updatedNumeroRit);
      }
      
      // Scarica e apre il PDF con autenticazione
      let pdfOpened = false;
      try {
        // Prima recupera i dati dell'intervento per ottenere il numero_relazione aggiornato
        let numeroRitFinale = updatedNumeroRit;
        try {
          const interventoResponse = await axios.get(`${API_URL}/interventi/${id}`, {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });
          if (interventoResponse.data?.numero_relazione) {
            numeroRitFinale = interventoResponse.data.numero_relazione;
            setNumeroRit(numeroRitFinale);
          }
        } catch (e) {
          console.warn('Impossibile recuperare numero relazione aggiornato:', e);
        }

        const pdfResponse = await axios.get(`${API_URL}/interventi/${id}/pdf`, {
          responseType: 'blob',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        
        // Verifica che il contenuto sia valido
        if (!pdfResponse.data || pdfResponse.data.size === 0) {
          alert('⚠️ Errore: Il PDF è vuoto o non valido.');
          navigate("/admin?tab=interventi");
          return;
        }
        
        // Usa sempre il numero RIT come nome file (più affidabile)
        const filename = numeroRitFinale ? `${numeroRitFinale}.pdf` : `RIT-${id}.pdf`;
        
        console.log('Nome file PDF:', filename);
        console.log('Numero RIT finale:', numeroRitFinale);
        
        // Crea un File object invece di Blob per preservare il nome
        const file = new File([pdfResponse.data], filename, { type: 'application/pdf' });
        const url = window.URL.createObjectURL(file);
        
        // Crea un link per il download con il nome corretto
        const link = document.createElement('a');
        link.href = url;
        link.download = filename; // Nome file corretto
        link.style.display = 'none';
        // Imposta anche l'attributo download esplicitamente
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        
        // Forza il download con il nome corretto
        // Usa un piccolo delay per assicurarsi che il link sia completamente nel DOM
        setTimeout(() => {
          link.click();
          pdfOpened = true;
          
          // Pulisci l'URL e rimuovi il link dopo un delay per permettere il download
          setTimeout(() => {
            try {
              window.URL.revokeObjectURL(url);
              if (document.body.contains(link)) {
                document.body.removeChild(link);
              }
            } catch (e) {
              console.warn('Errore pulizia URL:', e);
            }
          }, 2000);
        }, 50);
        
        if (pdfOpened) {
          alert(`✅ R.I.T. ${numeroRitFinale} AGGIORNATO!\nIl PDF si sta aprendo in un'altra scheda.`);
        }
      } catch (pdfError: any) {
        console.error("Errore apertura PDF:", pdfError);
        const errorMsg = pdfError.response?.data?.detail || pdfError.message || 'Errore sconosciuto';
        alert(`⚠️ R.I.T. ${updatedNumeroRit || 'aggiornato'}!\n\nErrore nell'apertura del PDF: ${errorMsg}\n\nPuoi scaricarlo dall'archivio interventi.`);
      }
      
      // Aspetta un po' prima di navigare per permettere l'apertura del PDF
      setTimeout(() => {
        navigate("/admin?tab=interventi");
      }, 2000);
    } catch (error: any) {
      console.error("ERRORE SALVATAGGIO:", error);
      if (error.response?.status === 401) {
        alert("Sessione scaduta. Effettua nuovamente il login.");
        navigate("/login");
      } else {
        alert("Errore durante l'aggiornamento: " + (error.response?.data?.detail || error.message));
      }
    } finally {
      setIsSubmitting(false);
      setIsSignatureModalOpen(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-gray-500">Caricamento...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <header className="sticky top-0 z-10 bg-white/90 backdrop-blur-md border-b border-gray-200 px-4 py-3 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => navigate('/')} 
            className="p-2 -ml-2 text-gray-600 rounded-full hover:bg-gray-100"
            title="Home"
          >
            <Home className="w-6 h-6" />
          </button>
          <button 
            onClick={() => navigate(-1)} 
            className="p-2 text-gray-600 rounded-full hover:bg-gray-100"
            title="Torna indietro"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-lg font-bold text-gray-900 tracking-tight">Modifica RIT</h1>
        </div>
        {numeroRit && (
          <div className="text-sm font-semibold text-blue-600 bg-blue-50 px-3 py-1.5 rounded-full">
            {numeroRit}
          </div>
        )}
      </header>
      
      <form onSubmit={handleSubmit(() => setIsSignatureModalOpen(true))} className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Sezioni identiche a NewInterventionPage */}
        {/* Cliente, Dettagli, Difetto Segnalato, Condizioni & Costi, Ricambi */}
        {/* Per brevità, riuso la stessa struttura */}
        
        <IOSCard>
          <h2 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 px-1">Cliente</h2>
          <div className="space-y-3">
            <IOSInput label="Ragione Sociale" value={watch("cliente_ragione_sociale")} disabled />
            <IOSInput label="Indirizzo" value={watch("cliente_indirizzo")} disabled />
            
            {clienteMultisede && sediCliente.length > 0 && (
              <div>
                <label className="text-xs font-semibold text-gray-600 mb-1 block">Sede Intervento</label>
                <select {...register("sede_id")} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-sm">
                  <option value="">Sede Legale</option>
                  {sediCliente.map((sede: any) => (
                    <option key={sede.id} value={sede.id}>{sede.nome_sede}</option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </IOSCard>

        <div>
          <div className="flex justify-between items-end mb-3 px-1">
            <h2 className="text-xs font-bold text-gray-500 uppercase tracking-widest">Dettaglio Lavori</h2>
            <button type="button" onClick={() => assetFields.append({ categoria_it: "Hardware", marca_modello: "", serial_number: "", part_number: "", descrizione_lavoro: "" })} className="text-xs font-bold text-blue-600 bg-white px-3 py-1.5 rounded-full flex items-center border border-gray-200 shadow-sm"><Plus className="w-3 h-3 mr-1" /> AGGIUNGI</button>
          </div>
          <div className="space-y-4">
            {assetFields.fields.map((field, index) => (
              <div key={field.id} className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm relative group">
                <button type="button" onClick={() => assetFields.remove(index)} className="absolute top-4 right-4 text-gray-300 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                <div className="mb-4 flex items-center gap-2"><span className="text-[10px] font-bold bg-gray-100 text-gray-500 px-2 py-1 rounded border border-gray-200 uppercase">Asset #{index + 1}</span></div>
                {macroCategoria === "Informatica & IT" && (
                  <select {...register(`dettagli.${index}.categoria_it`)} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none mb-3">
                    <option value="Hardware">Hardware</option>
                    <option value="Software">Software</option>
                    <option value="Network">Network</option>
                  </select>
                )}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3">
                  <IOSInput label="Prodotto / Modello" {...register(`dettagli.${index}.marca_modello`)} />
                  <IOSInput label="Serial Number" {...register(`dettagli.${index}.serial_number`)} />
                  <IOSInput label="Part Number" {...register(`dettagli.${index}.part_number`)} />
                </div>
                <textarea {...register(`dettagli.${index}.descrizione_lavoro`)} rows={3} className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm outline-none" placeholder="Descrizione lavoro..." />
              </div>
            ))}
          </div>
        </div>

        <IOSCard>
          <h2 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 px-1">Difetto Segnalato</h2>
          <textarea {...register("difetto_segnalato")} rows={3} className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm outline-none" placeholder="Descrivi il difetto segnalato dal cliente..." />
        </IOSCard>

        <IOSCard className="border-l-4 border-l-blue-600 shadow-md">
          <h2 className="text-lg font-bold text-gray-900 mb-5 flex items-center"><Receipt className="w-5 h-5 mr-2 text-blue-600" /> Condizioni & Costi</h2>
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className={contractLocked ? "opacity-60 pointer-events-none grayscale" : ""}>
              <Controller 
                name="is_contratto" 
                control={control} 
                render={({ field }) => (
                  <IOSToggle 
                    label="Contratto" 
                    checked={field.value} 
                    onChange={(checked) => {
                      field.onChange(checked);
                      if (checked) {
                        setValue("flag_diritto_chiamata", false);
                      }
                    }}
                    disabled={contractLocked}
                  />
                )}
              />
            </div>
            <Controller name="is_garanzia" control={control} render={({ field }) => <IOSToggle label="Garanzia" checked={field.value} onChange={field.onChange} />} />
            <Controller name="is_chiamata" control={control} render={({ field }) => <IOSToggle label="Chiamata" checked={field.value} onChange={field.onChange} disabled={contractLocked && watch("is_contratto")} />} />
            <Controller name="is_sopralluogo" control={control} render={({ field }) => <IOSToggle label="Sopralluogo" checked={field.value} onChange={field.onChange} />} />
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-4">
            <IOSInput label="Ora Inizio (HH:MM)" type="text" {...register("ora_inizio")} placeholder="09:00" />
            <IOSInput label="Ora Fine (HH:MM)" type="text" {...register("ora_fine")} placeholder="17:00" />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <IOSInput label="Costi Extra (€)" type="number" step="0.01" {...register("costi_extra", { valueAsNumber: true })} />
            <IOSInput label="Descrizione Costi Extra" {...register("descrizione_extra")} />
          </div>
        </IOSCard>

        <IOSCard>
          <div className="flex justify-between items-end mb-3 px-1">
            <h2 className="text-xs font-bold text-gray-500 uppercase tracking-widest">Ricambi Utilizzati</h2>
            <button type="button" onClick={() => ricambiFields.append({ descrizione: "", quantita: 1, prezzo_unitario: 0 })} className="text-xs font-bold text-blue-600 bg-white px-3 py-1.5 rounded-full flex items-center border border-gray-200 shadow-sm"><Plus className="w-3 h-3 mr-1" /> AGGIUNGI</button>
          </div>
          <div className="space-y-3">
            {ricambiFields.fields.map((field, index) => (
              <div key={field.id} className="bg-white p-4 rounded-xl border border-gray-200 flex gap-3 items-end">
                <div className="flex-1"><IOSInput label="Descrizione" {...register(`ricambi.${index}.descrizione`)} /></div>
                <div className="w-24"><IOSInput label="Q.tà" type="number" {...register(`ricambi.${index}.quantita`, { valueAsNumber: true })} /></div>
                <div className="w-32"><IOSInput label="Prezzo" type="number" step="0.01" {...register(`ricambi.${index}.prezzo_unitario`, { valueAsNumber: true })} /></div>
                <button type="button" onClick={() => ricambiFields.remove(index)} className="text-red-500 hover:text-red-700"><Trash2 className="w-4 h-4" /></button>
              </div>
            ))}
          </div>
        </IOSCard>

        <div className="flex gap-4">
          <button type="button" onClick={() => navigate("/admin?tab=interventi")} className="flex-1 px-6 py-4 bg-gray-200 text-gray-700 rounded-xl font-bold hover:bg-gray-300 transition-colors">Annulla</button>
          <button type="submit" disabled={isSubmitting} className="flex-1 px-6 py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-colors disabled:opacity-50">
            {isSubmitting ? "Salvataggio..." : "Salva e Rifirma"}
          </button>
        </div>
      </form>

      {/* Modale Firma */}
      {isSignatureModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
          <div className="bg-white rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl">
            <div className="bg-blue-600 p-4 flex justify-between items-center text-white">
              <h3 className="font-bold">Firme Digitali</h3>
              <button onClick={() => setIsSignatureModalOpen(false)} className="hover:bg-blue-700 p-1 rounded-full"><X className="w-6 h-6" /></button>
            </div>
            <div className="p-6 space-y-6">
              <div>
                <label className="block text-sm font-semibold mb-2">Firma Tecnico</label>
                <div className="border-2 border-gray-300 rounded-lg">
                  <SignatureCanvas ref={sigCanvasTecnico} canvasProps={{ className: "w-full" }} />
                </div>
                <button type="button" onClick={() => sigCanvasTecnico.current?.clear()} className="mt-2 text-sm text-gray-600 hover:text-gray-800">Cancella</button>
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Firma Cliente</label>
                <div className="border-2 border-gray-300 rounded-lg">
                  <SignatureCanvas ref={sigCanvasCliente} canvasProps={{ className: "w-full" }} />
                </div>
                <button type="button" onClick={() => sigCanvasCliente.current?.clear()} className="mt-2 text-sm text-gray-600 hover:text-gray-800">Cancella</button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <IOSInput id="nome_cliente" label="Nome Cliente" defaultValue={watch("nome_cliente")} />
                <IOSInput id="cognome_cliente" label="Cognome Cliente" defaultValue={watch("cognome_cliente")} />
              </div>
              <div className="flex gap-4">
                <button type="button" onClick={() => setIsSignatureModalOpen(false)} className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg font-semibold">Annulla</button>
                <button type="button" onClick={handleSignatureConfirm} className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700">Conferma e Salva</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

