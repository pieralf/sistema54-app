from pydantic import BaseModel, EmailStr, field_validator, model_validator, field_serializer
from typing import List, Optional, Dict, Any
from datetime import datetime, time
from enum import Enum

# Enums
class MacroCategoria(str, Enum):
    PRINTING = "Printing & Office"
    IT = "Informatica & IT"
    MANUTENZIONE = "Manutenzione Gen."
    FISCALI = "Sistemi Fiscali"

class CategoriaIT(str, Enum):
    HARDWARE = "Hardware"
    SOFTWARE = "Software"
    NETWORK = "Network"
    GENERICO = "Generico"

# --- IMPOSTAZIONI (Semplificato per evitare crash) ---
class ImpostazioniBase(BaseModel):
    nome_azienda: str = "Azienda Demo"
    indirizzo_completo: Optional[str] = ""
    telefono: Optional[str] = ""
    email: Optional[str] = ""
    email_notifiche_scadenze: Optional[str] = ""  # Email per notifiche scadenze noleggi
    p_iva: Optional[str] = ""
    colore_primario: str = "#4F46E5"
    logo_url: Optional[str] = ""
    testo_privacy: Optional[str] = ""
    tariffe_categorie: Dict[str, Any] = {} # JSON libero per evitare errori di validazione

class ImpostazioniCreate(ImpostazioniBase):
    pass

class ImpostazioniResponse(ImpostazioniBase):
    id: int
    class Config:
        from_attributes = True

# --- RIT / INTERVENTI ---
class RicambioBase(BaseModel):
    descrizione: str
    quantita: int
    prezzo_unitario: float

class RicambioCreate(RicambioBase):
    prodotto_id: Optional[int] = None  # ID del prodotto dal magazzino (opzionale)

class RicambioResponse(RicambioBase):
    id: int
    class Config:
        from_attributes = True

class DettaglioAssetBase(BaseModel):
    marca_modello: str
    descrizione_lavoro: str
    serial_number: Optional[str] = ""
    part_number: Optional[str] = None  # Part number del prodotto

class DettaglioAssetCreate(DettaglioAssetBase):
    pass

class DettaglioAssetResponse(DettaglioAssetBase):
    id: int
    class Config:
        from_attributes = True

class InterventoBase(BaseModel):
    macro_categoria: MacroCategoria
    cliente_id: int  # ID del cliente
    cliente_ragione_sociale: str 
    cliente_indirizzo: Optional[str] = ""
    numero_relazione: Optional[str] = "" # Gestito dal backend
    sede_id: Optional[int] = None  # ID della sede selezionata (se multisede)
    
    # Flags
    is_contratto: bool = False
    is_garanzia: bool = False
    is_chiamata: bool = False
    flag_diritto_chiamata: bool = True  # Flag per diritto di chiamata
    
    # Firme (Base64)
    firma_tecnico: Optional[str] = None
    firma_cliente: Optional[str] = None
    nome_cliente: Optional[str] = None
    cognome_cliente: Optional[str] = None
    costi_extra: Optional[float] = 0.0
    descrizione_extra: Optional[str] = None
    difetto_segnalato: Optional[str] = None  # Campo separato per il difetto segnalato
    ora_inizio: Optional[str] = None  # Formato HH:MM
    ora_fine: Optional[str] = None    # Formato HH:MM

class InterventoCreate(InterventoBase):
    dettagli: List[DettaglioAssetCreate] = []
    ricambi: List[RicambioCreate] = []

class InterventoResponse(InterventoBase):
    id: int
    data_creazione: datetime
    dettagli: List[DettaglioAssetResponse] = []
    ricambi_utilizzati: List[RicambioResponse] = []
    # Sovrascriviamo i campi time per gestire la conversione
    ora_inizio: Optional[str] = None  # Formato HH:MM
    ora_fine: Optional[str] = None    # Formato HH:MM
    
    @model_validator(mode='before')
    @classmethod
    def convert_time_fields(cls, data: Any) -> Any:
        """Converte datetime.time in stringhe formato HH:MM"""
        if hasattr(data, 'ora_inizio') and isinstance(data.ora_inizio, time):
            data.ora_inizio = data.ora_inizio.strftime('%H:%M')
        if hasattr(data, 'ora_fine') and isinstance(data.ora_fine, time):
            data.ora_fine = data.ora_fine.strftime('%H:%M')
        return data
    
    class Config:
        from_attributes = True

# --- CLIENTI ---
class SedeClienteBase(BaseModel):
    nome_sede: str
    indirizzo_completo: str
    citta: Optional[str] = ""
    cap: Optional[str] = ""
    telefono: Optional[str] = ""
    email: Optional[str] = ""

class SedeClienteCreate(SedeClienteBase):
    id: Optional[int] = None  # ID opzionale per identificare sedi esistenti durante l'aggiornamento

class SedeClienteResponse(SedeClienteBase):
    id: int
    cliente_id: int
    class Config:
        from_attributes = True

class AssetClienteBase(BaseModel):
    tipo_asset: str  # "Printing" o "IT"
    marca: Optional[str] = None
    modello: Optional[str] = None
    matricola: Optional[str] = None
    data_installazione: Optional[datetime] = None
    data_scadenza_noleggio: Optional[datetime] = None
    
    # Campi specifici per Printing
    is_colore: Optional[bool] = None  # True = colore, False = b/n
    tipo_formato: Optional[str] = None  # A4, A3, A0
    contatore_iniziale_bn: Optional[int] = 0
    contatore_iniziale_colore: Optional[int] = 0
    copie_incluse_bn: Optional[int] = None  # None = illimitate
    copie_incluse_colore: Optional[int] = None  # None = illimitate
    costo_copia_bn_fuori_limite: Optional[float] = None
    costo_copia_colore_fuori_limite: Optional[float] = None
    costo_copia_bn_non_incluse: Optional[float] = None
    costo_copia_colore_non_incluse: Optional[float] = None
    
    # Campi specifici per IT
    codice_prodotto: Optional[str] = None
    seriale: Optional[str] = None
    descrizione: Optional[str] = None
    is_nuovo: Optional[bool] = None  # True = nuovo, False = ricondizionato

class AssetClienteCreate(AssetClienteBase):
    pass

class AssetClienteResponse(AssetClienteBase):
    id: int
    cliente_id: int
    class Config:
        from_attributes = True

class ClienteBase(BaseModel):
    ragione_sociale: str
    p_iva: Optional[str] = ""
    indirizzo: Optional[str] = ""
    citta: Optional[str] = ""
    cap: Optional[str] = ""
    codice_fiscale: Optional[str] = ""
    email_amministrazione: Optional[str] = ""
    is_pa: Optional[bool] = False
    codice_sdi: Optional[str] = ""
    has_multisede: Optional[bool] = False
    has_noleggio: Optional[bool] = False
    has_contratto_assistenza: Optional[bool] = False

class ClienteCreate(ClienteBase):
    sedi: Optional[List[SedeClienteCreate]] = []
    assets_noleggio: Optional[List[AssetClienteCreate]] = []

class ClienteResponse(ClienteBase):
    id: int
    sedi: List[SedeClienteResponse] = []
    assets_noleggio: List[AssetClienteResponse] = []
    class Config:
        from_attributes = True

# --- AUTENTICAZIONE ---
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict
    requires_2fa: Optional[bool] = False  # Se True, richiede verifica 2FA

class LoginRequest(BaseModel):
    email: EmailStr
    password: str
    two_factor_code: Optional[str] = None  # Codice 2FA o backup code

class TwoFactorSetupResponse(BaseModel):
    secret: str
    qr_code: str  # Base64 encoded PNG
    backup_codes: List[str]

class TwoFactorVerifyRequest(BaseModel):
    code: str  # Codice TOTP o backup code

class OAuthLoginRequest(BaseModel):
    provider: str  # 'google', 'microsoft'
    token: str  # Token dal provider

class UserBase(BaseModel):
    email: EmailStr
    nome_completo: str
    ruolo: str

class UserCreate(UserBase):
    password: str

class UserResponse(UserBase):
    id: int
    is_active: bool
    oauth_provider: Optional[str] = None
    last_login: Optional[datetime] = None
    permessi: Optional[Dict[str, Any]] = {}
    two_factor_enabled: Optional[bool] = False
    class Config:
        from_attributes = True

class UserUpdate(BaseModel):
    nome_completo: Optional[str] = None
    ruolo: Optional[str] = None
    is_active: Optional[bool] = None
    password: Optional[str] = None
    permessi: Optional[Dict[str, Any]] = None  # Permessi granulari

# --- MAGAZZINO ---
class ProdottoBase(BaseModel):
    codice_articolo: str
    descrizione: str
    prezzo_vendita: float = 0.0
    costo_acquisto: float = 0.0
    giacenza: int = 0
    categoria: Optional[str] = None

class ProdottoCreate(ProdottoBase):
    pass

class ProdottoUpdate(BaseModel):
    descrizione: Optional[str] = None
    prezzo_vendita: Optional[float] = None
    costo_acquisto: Optional[float] = None
    giacenza: Optional[int] = None
    categoria: Optional[str] = None

class ProdottoResponse(ProdottoBase):
    id: int
    class Config:
        from_attributes = True